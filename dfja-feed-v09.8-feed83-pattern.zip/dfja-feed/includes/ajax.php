<?php

if (!defined('ABSPATH')) exit;

function dfja_ajax_post_id() {
    return absint($_POST['post_id'] ?? $_GET['post_id'] ?? 0);
}

function dfja_interaction_key($post_id) {
    $visitor = sanitize_text_field($_POST['visitor_id'] ?? $_GET['visitor_id'] ?? '');
    $identity = $visitor ?: ($_SERVER['REMOTE_ADDR'] ?? '') . '|' . ($_SERVER['HTTP_USER_AGENT'] ?? '');
    return hash_hmac('sha256', $post_id . '|' . $identity, wp_salt('auth'));
}

add_action('wp_ajax_dfja_get_interactions', 'dfja_get_interactions');
add_action('wp_ajax_nopriv_dfja_get_interactions', 'dfja_get_interactions');
function dfja_get_interactions() {
    $post_id = dfja_ajax_post_id();
    if (!$post_id || get_post_status($post_id) !== 'publish') wp_send_json_error(['message' => 'Matéria indisponível.'], 404);
    $liked_by = (array) get_post_meta($post_id, 'dfja_like_visitors', true);
    wp_send_json_success([
        'post_id' => $post_id,
        'like_count' => count($liked_by),
        'liked' => isset($liked_by[dfja_interaction_key($post_id)]),
    ]);
}

add_action('wp_ajax_dfja_track_interaction', 'dfja_track_interaction');
add_action('wp_ajax_nopriv_dfja_track_interaction', 'dfja_track_interaction');
function dfja_track_interaction() {
    check_ajax_referer('dfja_ajax', 'nonce');
    $post_id = dfja_ajax_post_id();
    $type = sanitize_key($_POST['type'] ?? '');
    if (!$post_id || !$type) wp_send_json_error(['message' => 'Dados inválidos'], 400);
    if (!in_array($type, ['like', 'view'], true)) wp_send_json_error(['message' => 'Interação inválida'], 400);
    if (get_post_status($post_id) !== 'publish') wp_send_json_error(['message' => 'Matéria indisponível.'], 404);
    if ($type === 'like') {
        $liked_by = (array) get_post_meta($post_id, 'dfja_like_visitors', true);
        $key = dfja_interaction_key($post_id);
        $liked = sanitize_key($_POST['liked'] ?? '') === '1';
        if ($liked) $liked_by[$key] = time();
        else unset($liked_by[$key]);
        update_post_meta($post_id, 'dfja_like_visitors', $liked_by);
        update_post_meta($post_id, 'dfja_like_count', count($liked_by));
        wp_send_json_success(['post_id' => $post_id, 'type' => 'like', 'count' => count($liked_by), 'liked' => $liked]);
    }
    $meta_key = $type === 'like' ? 'dfja_like_count' : 'dfja_view_count';
    $count = absint(get_post_meta($post_id, $meta_key, true)) + 1;
    update_post_meta($post_id, $meta_key, $count);
    wp_send_json_success(['post_id' => $post_id, 'type' => $type, 'count' => $count]);
}

add_action('wp_ajax_dfja_get_comments', 'dfja_get_comments');
add_action('wp_ajax_nopriv_dfja_get_comments', 'dfja_get_comments');
function dfja_get_comments() {
    $post_id = dfja_ajax_post_id();
    if (!$post_id) wp_send_json_error(['message' => 'Post inválido'], 400);

    $comments = get_comments([
        'post_id' => $post_id,
        'status' => 'approve',
        'number' => 50,
        'type' => 'comment',
    ]);

    wp_send_json_success(['comments' => array_map(function ($comment) {
        return [
            'id' => (int) $comment->comment_ID,
            'author_name' => $comment->comment_author,
            'date' => $comment->comment_date_gmt,
            'content' => wp_kses_post($comment->comment_content),
        ];
    }, $comments)]);
}

add_action('wp_ajax_dfja_submit_comment', 'dfja_submit_comment');
add_action('wp_ajax_nopriv_dfja_submit_comment', 'dfja_submit_comment');
function dfja_submit_comment() {
    check_ajax_referer('dfja_ajax', 'nonce');
    $post_id = dfja_ajax_post_id();
    $content = sanitize_textarea_field($_POST['content'] ?? '');
    $author = sanitize_text_field($_POST['author'] ?? '');
    if (!$post_id || !$content) wp_send_json_error(['message' => 'Escreva um comentário.'], 400);
    if (get_post_status($post_id) !== 'publish') wp_send_json_error(['message' => 'Matéria indisponível.'], 404);
    if (!comments_open($post_id)) wp_send_json_error(['message' => 'Os comentários estão fechados para esta matéria.'], 403);
    $comment_id = wp_new_comment([
        'comment_post_ID' => $post_id,
        'comment_content' => $content,
        'comment_author' => $author ?: 'Leitor DFJÁ',
        'comment_author_IP' => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
        'comment_approved' => 0,
    ], true);
    if (is_wp_error($comment_id)) wp_send_json_error(['message' => $comment_id->get_error_message()], 400);
    wp_send_json_success(['message' => 'Comentário enviado para aprovação.']);
}
