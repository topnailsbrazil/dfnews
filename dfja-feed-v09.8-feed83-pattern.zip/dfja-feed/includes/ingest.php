<?php

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    register_rest_route('dfja/v1', '/ingest', [
        'methods' => WP_REST_Server::CREATABLE,
        'callback' => 'dfja_ingest_article',
        'permission_callback' => 'dfja_ingest_permission',
    ]);
});

function dfja_ingest_permission(WP_REST_Request $request) {
    $configured_key = defined('DFJA_INGEST_KEY') ? (string) DFJA_INGEST_KEY : '';
    $provided_key = (string) $request->get_header('x-dfja-ingest-key');
    if (!$configured_key || !$provided_key || !hash_equals($configured_key, $provided_key)) {
        return new WP_Error('dfja_ingest_forbidden', 'Chave de ingestão inválida.', ['status' => 401]);
    }
    return true;
}

function dfja_ingest_article(WP_REST_Request $request) {
    $payload = (array) $request->get_json_params();
    $title = sanitize_text_field($payload['title'] ?? '');
    $content = wp_kses_post($payload['content'] ?? '');
    if (!$title || !$content) return new WP_Error('dfja_ingest_invalid', 'title e content são obrigatórios.', ['status' => 400]);

    // Idempotência: reentregas do n8n não podem criar matérias duplicadas.
    $item_id = sanitize_text_field($payload['n8n_item_id'] ?? '');
    if ($item_id !== '') {
        $existing = get_posts([
            'post_type' => 'post',
            'post_status' => 'any',
            'posts_per_page' => 1,
            'fields' => 'ids',
            'meta_key' => 'dfja_n8n_item_id',
            'meta_value' => $item_id,
        ]);
        if (!empty($existing)) {
            return new WP_REST_Response(['success' => true, 'post_id' => (int) $existing[0], 'status' => 'existing'], 200);
        }
    }

    $post_id = wp_insert_post([
        'post_title' => $title,
        'post_content' => $content,
        'post_excerpt' => sanitize_textarea_field($payload['excerpt'] ?? ''),
        'post_status' => 'pending',
        'post_type' => 'post',
        'post_author' => get_current_user_id() ?: 1,
    ], true);
    if (is_wp_error($post_id)) return $post_id;

    $meta = [
        'dfja_source_name' => sanitize_text_field($payload['source_name'] ?? ''),
        'dfja_source_url' => esc_url_raw($payload['source_url'] ?? ''),
        'dfja_image_url' => esc_url_raw($payload['image_url'] ?? ''),
        'dfja_video_url' => esc_url_raw($payload['video_url'] ?? ''),
        'dfja_instagram_url' => esc_url_raw($payload['instagram_url'] ?? ''),
        'dfja_ai_status' => 'generated',
        'dfja_editor_status' => 'awaiting_review',
        'dfja_n8n_item_id' => $item_id,
    ];
    foreach ($meta as $key => $value) if ($value !== '') update_post_meta($post_id, $key, $value);
    if (!empty($payload['category'])) wp_set_post_categories($post_id, [absint($payload['category'])], false);

    return new WP_REST_Response(['success' => true, 'post_id' => (int) $post_id, 'status' => 'pending'], 201);
}
